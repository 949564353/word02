package com.hongang.ppt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeigouApplicationTests {

    @Test
    void contextLoads() {
    }

}
