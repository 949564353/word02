package com.hongang.ppt.controller;

import com.hongang.ppt.common.Result;
import com.hongang.ppt.common.vo.LoginUserVo;
import com.hongang.ppt.service.UserServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("user")
@Api(value = "user", tags = "用户信息", description = "用户接口相关")
public class UserController {

    @Autowired
    private UserServiceImpl userService;


    @ApiOperation("用户新增接口")
    @PostMapping(value = "/userAdd")
    public Result userAdd(@Valid @RequestBody LoginUserVo userVo) {
        return userService.userAdd(userVo);
    }

    @ApiOperation("用户登录接口")
    @PostMapping(value = "/userLogin")
    public Result userLogin(@Valid @RequestBody LoginUserVo userVo) {
        return userService.userLogin(userVo);
    }

}
