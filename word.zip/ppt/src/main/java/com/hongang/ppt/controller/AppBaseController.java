package com.hongang.ppt.controller;

import com.hongang.ppt.common.IsInvalidDto;
import com.hongang.ppt.common.Result;
import com.hongang.ppt.common.vo.*;
import com.hongang.ppt.service.PlanCustomServiceImpl;
import com.hongang.ppt.common.vo.*;
import com.hongang.ppt.service.AppBaseServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiOperationSort;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


@RestController
@RequestMapping("base")
@Api(value = "base", tags = "内购接口", description = "内购接口")
public class AppBaseController {

    @Autowired
    private AppBaseServiceImpl appBaseService;

    @Autowired
    private PlanCustomServiceImpl planCustomService;


    @ApiOperationSort(2)
    @ApiOperation(value = "广告是否打开", response = IsInvalidDto.class)
    @PostMapping(value = "/isOpen")
    public Result isOpen(@Valid @RequestBody IsInvalidVo isInvalidVo) {
        return appBaseService.isOpen(isInvalidVo);
    }


    @ApiOperation("配置文案信息")
    @PostMapping(value = "/savePlanInfo")
    public Result savePlanInfo(@Valid @RequestBody List<AppPlanVo> planVoList, @RequestParam(value = "version",required = true) String version) {
        return appBaseService.savePlanInfo(planVoList,version);
    }

    @ApiOperation("查询文案信息")
    @PostMapping(value = "/selectPlanInfo")
    public Result selectPlanInfo(@Valid @RequestBody VersionVo versionVo) {
        return appBaseService.selectPlanInfo(versionVo);
    }

    @ApiOperation("内网支付成功生成订单")
    @PostMapping(value = "/verification")
    public Result verification(@Valid @RequestBody AppOrderVo orderVo) {
        return appBaseService.verification(orderVo);
    }

    @ApiOperation("配置订制文案")
    @PostMapping(value = "/savePlanCustom")
    public Result savePlanCustom(@Valid @RequestBody List<PlanCustomVo> planCustomVoList, @RequestParam(value = "version",required = true)String version) {
        return planCustomService.savePlanCustom(planCustomVoList,version);
    }

    @ApiOperation("查询订制文案")
    @PostMapping(value = "/selectPlanCustom")
    public Result selectPlanCustom(@Valid @RequestBody VersionVo versionVo) {
        return planCustomService.selectPlanCustom(versionVo);
    }
}
